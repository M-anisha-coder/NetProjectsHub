﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using CTSLibrary;

namespace Xml_read_write
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string value = Environment.GetEnvironmentVariable("xml_files");
            string xml_path = value + "\\" +"xml_doc";
            writing_xml_db("Mani", "kunal", "invite", "invite for birthday celebration ", xml_path);
        }

        protected override void OnStop()
        {
        }

        private void writing_xml_db(String To_email, string from_email, string heading_email, string body_email, string xmlpath)
        {
            Webservice.DBConnectionString = "manishaojt";
            Webservice.DBType = "SQL";
            Webservice.WebserviceURL = "http://20.235.90.250/DBInteraction/NGCTSDBInteraction.asmx";
            string sReturnValue = "";
            string sQuerystatement = "prc_email ";
            string sQueryType = "storedproc";
            DataTable ResultTable = new DataTable();
            Webservice.DBParameter[] db_parameter = null;

            try
            {
                Array.Resize<Webservice.DBParameter>(ref db_parameter, 4);


                db_parameter[0].strParamName = "@TO_email";
                db_parameter[0].strParamType = "Varchar";
                db_parameter[0].strParamValue = To_email;
                db_parameter[0].strParamDirection = "in";
                db_parameter[0].intParamLength = To_email.Length;

                db_parameter[0].strParamName = "@from_email";
                db_parameter[0].strParamType = "Varchar";
                db_parameter[0].strParamValue = from_email;
                db_parameter[0].strParamDirection = "in";
                db_parameter[0].intParamLength = from_email.Length;


                db_parameter[0].strParamName = "@heading_email";
                db_parameter[0].strParamType = "Varchar";
                db_parameter[0].strParamValue = heading_email;
                db_parameter[0].strParamDirection = "in";
                db_parameter[0].intParamLength = heading_email.Length;

                db_parameter[0].strParamName = "@body_email";
                db_parameter[0].strParamType = "Varchar";
                db_parameter[0].strParamValue = body_email;
                db_parameter[0].strParamDirection = "in";
                db_parameter[0].intParamLength = body_email.Length;

                sReturnValue = Webservice.ExecuteDBOperation(sQuerystatement, sQueryType, db_parameter, ref ResultTable);
                ResultTable = ResultTable.DataSet.Tables["Result"];


            }
            catch (Exception ex)
            {
                Console.WriteLine("something went wrong " + ex.Message);

            }

        }




































    }
}
