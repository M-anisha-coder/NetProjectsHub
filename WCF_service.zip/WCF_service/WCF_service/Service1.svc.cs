﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WCF_service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {

        public string Insert(Insertuser user)
        {

            string msg;
            string db_path = @"Data Source=192.168.134.164 ;Initial Catalog =db108;User ID=user108;Password=db108";
            SqlConnection conn = new SqlConnection(db_path);
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into App_Users (UserId,Name,Contact,Password) values(@UserId,@Name,@Contact,@Password)", conn);
            cmd.Parameters.AddWithValue("@UserId", user.UserId);
            cmd.Parameters.AddWithValue("@Name", user.Name);
            cmd.Parameters.AddWithValue("@Contact", user.Contact);
            cmd.Parameters.AddWithValue("@Password", user.Password);
            int R = cmd.ExecuteNonQuery();
            if (R == 1)
            {
                msg = "successful insertion";
            }
            else
            {
                msg = "failed to inert";

            }
            return msg;
        }

        public string Delete(deleteuser user)
        {

            string msg;
            string db_path = @"Data Source=192.168.134.164 ;Initial Catalog =db108;User ID=user108;Password=db108";
            SqlConnection conn = new SqlConnection(db_path);
            conn.Open();
            SqlCommand cmd = new SqlCommand("Delete from App_Users where UserId = @UserId ", conn);
            cmd.Parameters.AddWithValue("@UserId", user.UserId);

            int R = cmd.ExecuteNonQuery();
            if (R == 1)
            {
                msg = "successful deletion";
            }
            else
            {
                msg = "failed to deletes";

            }
            return msg;
        }


    }
}
